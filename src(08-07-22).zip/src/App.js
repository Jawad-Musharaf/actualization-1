import "./App.css";
import React from "react";
import Main from "./components/Main";
import './animate.css';

function App() {
  return (
  
      <Main />
 
  );
}

export default App;
