import React from 'react'

const Info = () => {
  return (
    <div className='info'>Info</div>
  )
}

export default Info